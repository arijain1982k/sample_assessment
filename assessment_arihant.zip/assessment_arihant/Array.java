public class Array{
	public static void main(String[] arg){
		int arr[] = new int[5];
		arr = [1,2,3,4,5,6];
	}}